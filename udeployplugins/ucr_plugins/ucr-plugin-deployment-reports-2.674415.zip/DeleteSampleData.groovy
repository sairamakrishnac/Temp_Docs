#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.ibm.icu.text.DateFormat
import com.urbancode.air.*
import com.urbancode.urelease.endpoint.framework.DeploymentReportsData;
import com.urbancode.release.rest.framework.Clients;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

Clients.loginWithToken(props['releaseServerUrl'], props['releaseToken']);
DeploymentReportsData.clearData()
println "Successfully deleted sample data!"