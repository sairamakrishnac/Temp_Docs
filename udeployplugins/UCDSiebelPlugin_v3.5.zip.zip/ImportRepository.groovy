/**
 * � Copyright IBM Corporation 2015.
 * This is licensed under the following license.
 * The Eclipse Public 1.0 License (http://www.eclipse.org/legal/epl-v10.html)
 * U.S. Government Users Restricted Rights:  Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

String myName="ImportRepository";
/* This gets us the plugin tool helper. 
 * This assumes that args[0] is input props file and args[1] is output props file.
 * By default, this is true. If your plugin.xml looks like the example. 
 * Any arguments you wish to pass from the plugin.xml to this script that you don't want to 
 * pass through the step properties can be accessed using this argument syntax
 */
def apTool = new AirPluginTool(this.args[0], this.args[1]) 

/* Here we call getStepProperties() to get a Properties object that contains the step properties
 * provided by the user. 
 */
def props = apTool.getStepProperties();

/* This is how you retrieve properties from the object. You provide the "name" attribute of the 
 * <property> element 
 * 
 */
DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
Date date = new Date();

def SiebelHomeDirectory = props['SiebelHomeDirectory'];
def SiebelODBCDataSource = props['SiebelODBCDataSource'];
def SiebelDBTableOwner = props['SiebelDBTableOwner'];
def SiebelAdminUsername = props['SiebelUser'];
def SiebelAdminPassword = props['SiebelPass'];
def rpdFullPath = props['SiebelRepPath'];
def repository = props['SiebelRepName'];

def dirOffset = props['dirOffset'];
if(System.getProperty("os.name").startsWith("Win"))
{
	isUnix=false;
}
else
{
	isUnix=true;
}

def workDir = new File(System.getProperty("java.io.tmpdir").toString()+System.getProperty("file.separator").toString()+"ucd_sieb_"+dateFormat.format(date));
def scriptFile = new File(workDir.path+workDir.separator+"scriptFile");

try
{
	println(myName+": Making directory ["+workDir.path+"]");
	workDir.mkdir();
	writer = new PrintWriter(scriptFile);
	if(isUnix)
	{
		writer.println("SIEBEL_HOME="+SiebelHomeDirectory+"; export SIEBEL_HOME");
		writer.println(". \$SIEBEL_HOME/siebenv.sh");
		//./repimexp /A I /U sadmin /P <sadmin password> /C <ODBC_NAME> /D SIEBEL /R "Siebel Repository 20150329" 
		//	/F /appl/sblappl1/siebel/temp/siebel_rep.data /Z 5000 /H 5000 /G ALL
		String sComLine=new String();
		sComLine="\$SIEBEL_HOME/bin/repimexp /A /I /U "+SiebelAdminUsername+" /P "+SiebelAdminPassword+" /C "+SiebelODBCDataSource;
		sComLine=sComLine+" /D "+SiebelDBTableOwner+" /R \""+repository+"\" /F "+rpdFullPath+" /Z 5000 /H 5000 /G ALL";
		writer.println(sComLine);
	}
	else
	{
		writer.println("set SIEBEL_HOME="+SiebelHomeDirectory);
		//FILL IN REST OF SIEBEL ON WINDOWS THINGS
	}
	writer.close();
	scriptFile.setExecutable(true, false);
}
catch(IOException e)
{
	println(myName+": ["+e.getMessage()+"]");
	e.printStackTrace();
	exit(-1);
}

//example commandHelper
def ch = new CommandHelper(workDir);
def args = ['./scriptFile','',''];
ch.runCommand("Importing Siebel repository", args);
scriptFile.deleteOnExit();
workDir.deleteOnExit();

//Set an output property
apTool.setOutputProperty("outPropName", "outPropValue");

apTool.storeOutputProperties();//write the output properties to the file
