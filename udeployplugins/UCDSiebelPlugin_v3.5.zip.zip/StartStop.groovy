/**
 * � Copyright IBM Corporation 2015.
 * This is licensed under the following license.
 * The Eclipse Public 1.0 License (http://www.eclipse.org/legal/epl-v10.html)
 * U.S. Government Users Restricted Rights:  Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;
import com.urbancode.air.ExitCodeException;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

String myName="StartStop";
/* This gets us the plugin tool helper. 
 * This assumes that args[0] is input props file and args[1] is output props file.
 * By default, this is true. If your plugin.xml looks like the example. 
 * Any arguments you wish to pass from the plugin.xml to this script that you don't want to 
 * pass through the step properties can be accessed using this argument syntax
 */
def apTool = new AirPluginTool(this.args[0], this.args[1]) 

/* Here we call getStepProperties() to get a Properties object that contains the step properties
 * provided by the user. 
 */
def props = apTool.getStepProperties();

/* This is how you retrieve properties from the object. You provide the "name" attribute of the 
 * <property> element 
 * 
 */
DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
Date date = new Date();

def ServerHomeDirectory = props['SiebelHomeDirectory'];
def ActionString = props['Action'];
def ServerType = props['ServerType'];
def SiebEnterprise = props['SiebelEnt'];
def gwServer = props['GatewayServer'];
def gwPort = props['GatewayPort'];
def sbUser = props['SiebelUser'];
def sbPass = props['SiebelPass']
///THIS NEEDS TO CHANGE
def sbServer = props['SiebelServer'];

def dirOffset = props['dirOffset'];
boolean isUnix=true
if(System.getProperty("os.name").startsWith("Win"))
{
	isUnix=false;
	println(myName+": We are running in a Windows environment")
}
else
{
	//Here I assume that the syntax of AIX command is the same as Linux and other Unix commands for Siebel. Could be wrong though CAREFUL
	isUnix=true;
	println(myName+": We are running in a Unix/Linux environment")
}
println System.getenv("HOME").toString()
def workDir = new File("ucd_sieb_"+dateFormat.format(date));
def scriptFile = new File(workDir.path+workDir.separator+"scriptFile");
def checkFile =  new File(workDir.path+workDir.separator+"checkFile");

boolean bToCheck = false;

def cleanUp = {
	println(myName+": Cleaning up.")
	if(scriptFile.exists())
	{
		if(!scriptFile.delete())
		{
			println(myName+": Could not delete script:["+scriptFile.path+"] please delete manually")
		}
	}
	if(checkFile.exists())
	{
		if(!checkFile.delete())
		{
			println(myName+": Could not delete check script:["+checkFile.path+"] please delete manually")
		}
	}
	if(workDir.exists())
	{
		if(!workDir.deleteDir())
		{
			println(myName+": Could not delete directory:["+workDir.path+"] please delete manually")
		}
	}
}

try
{
//	alias startapa='/usr/IBM/HTTPServer/bin/startapa'
//	alias startgate='. $HOME/.profile;. $GATEWAY_HOME/siebenv.sh ;$GATEWAY_HOME/bin/start_ns'
//	alias startsiebel='. $HOME/.profile;. $SIEBEL_HOME/siebenv.sh ;$SIEBEL_HOME/bin/start_server all'
//	alias stopapa='/usr/IBM/HTTPServer/bin/stopapa'
//	alias stopgate='. $HOME/.profile;. $GATEWAY_HOME/siebenv.sh ; $GATEWAY_HOME/bin/stop_ns'
//	alias stopsiebel='. $HOME/.profile; . $SIEBEL_HOME/siebenv.sh ; $SIEBEL_HOME/bin/stop_server all'
	
	println(myName+": Making directory ["+workDir.path+"]");
	workDir.mkdir();
	writer = new PrintWriter(scriptFile);
	envString=new String();
	commandString=new String();
	if(isUnix)
	{
		println(myName+": Server Type: ["+ServerType+"] in dir:["+ServerHomeDirectory+"]");
		switch(ServerType)
		{
			case ~/Siebel/:
				envString=". \$HOME/.profile; SIEBEL_HOME="+ServerHomeDirectory+"; export SIEBEL_HOME; . \$SIEBEL_HOME/siebenv.sh;";
				if(ActionString.toString().equalsIgnoreCase("start"))
				{
					println(myName+": Cooking Siebel Server start script");
					commandString="\$SIEBEL_HOME/bin/start_server all";
					bToCheck=true;
				}
				else
				{
					println(myName+": Cooking Siebel Server stop script");
					commandString="\$SIEBEL_HOME/bin/stop_server all";
				}
				break;
			case ~/Gateway/:
				envString=". \$HOME/.profile; GATEWAY_HOME="+ServerHomeDirectory+"; export GATEWAY_HOME; . \$GATEWAY_HOME/siebenv.sh;";
				if(ActionString.toString().equalsIgnoreCase("start"))
				{
					println(myName+": Cooking Gateway Server start script");
					commandString="\$GATEWAY_HOME/bin/start_ns";
				}
				else
				{
					println(myName+": Cooking Gateway Server stop script");
					commandString="\$GATEWAY_HOME/bin/stop_ns";
				}
				break;
			case ~/Web/:
				envString=". \$HOME/.profile; APACHE_HOME="+ServerHomeDirectory+"; export APACHE_HOME;";
				if(ActionString.toString().equalsIgnoreCase("start"))
				{
					println(myName+": Cooking Apache Server start script");
					commandString="\$APACHE_HOME/bin/startapa";
				}
				else
				{
					println(myName+": Cooking Apache Server stop script");
					commandString="\$APACHE_HOME/bin/stopapa";
				}
				break;
			default:
				System.out.println(myName+": invalid Action");
				writer.close();
				exit(-1);
		}
		println(myName+": "+envString);
		println(myName+": "+commandString);
		writer.println("#!/usr/bin/sh");
		writer.println(envString);
		writer.println(commandString);
	}
	else
	{
		writer.println(myName+" Windows is not yet supported - please add code here TAG:STARTSTOP")
		//FILL IN REST OF SIEBEL ON WINDOWS THINGS. Don't have access to a windows Siebel server, so can't test it.
	}
	writer.close();
	scriptFile.setExecutable(true, false);
}
catch(IOException e)
{
	cleanUp.call()
	println(myName+": ["+e.getMessage()+"]");
	e.printStackTrace();
	System.exit(-1);
}

//example commandHelper
def ch = new CommandHelper(workDir);
def args = ['./scriptFile','',''];
def	checkArgs = ['./checkFile', '', ''];
try
{
	ch.runCommand("Applying Action on Server", args);
}
catch (ExitCodeException e)
{
	cleanUp.call()
	println(myName+": ["+e.getMessage()+"]");
	e.printStackTrace();
	System.exit(-1);
}
if(bToCheck)
{
	if(isUnix)
	{
		println(myName+": Making check script[");
		writer = new PrintWriter(checkFile);
		writer.println(". \$HOME/.profile; SIEBEL_HOME="+ServerHomeDirectory+"; export SIEBEL_HOME; . \$SIEBEL_HOME/siebenv.sh;");
		println("outp=`\$SIEBEL_HOME/bin/srvrmgr /g "+gwServer.toString()+":"+gwPort.toString()+" /e "+SiebEnterprise.toString()+" /u "+sbUser.toString()+" /p "+sbPass.toString()+" /c \"list servers\"`");
		writer.println("outp=`\$SIEBEL_HOME/bin/srvrmgr /g "+gwServer.toString()+":"+gwPort.toString()+" /e "+SiebEnterprise.toString()+" /u "+sbUser.toString()+" /p "+sbPass.toString()+" /c \"list servers\"`");
		writer.println("echo \$outp");
		writer.println("mycount=`echo \$outp|grep -i "+sbServer.toString()+"|grep -c Running`");
		writer.println("if [ \$mycount = 0 ]; then exit -1; else exit 0; fi");
		writer.close();
		checkFile.setExecutable(true,false);
	}	
	else
	{
		writer.println(myName+" Windows is not yet supported - please add code here TAG:CHECK")
		//FILL IN REST OF SIEBEL ON WINDOWS THINGS. Don't have access to a windows Siebel server, so can't test it.
	}
}
int rc=0;
ch.ignoreExitValue(true);
while(bToCheck)
{
	sleep(5000);
	rc=ch.runCommand(dateFormat.format(date)+": "+myName+": Checking to see if Siebel Server has started", checkArgs);
	println(myName+": check returned "+rc)
	if(rc==0)
	{
		bToCheck=false;
	}
}
cleanUp.call()
//Set an output property
apTool.setOutputProperty("outPropName", "outPropValue");

apTool.storeOutputProperties();//write the output properties to the file
