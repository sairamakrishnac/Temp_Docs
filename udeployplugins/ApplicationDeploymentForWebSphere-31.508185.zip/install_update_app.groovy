import java.io.*;
import java.util.*;


final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
out = System.out;
def wsadmin = isWindows ? "wsadmin.bat" : "wsadmin.sh"

final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
final def inputPropsStream = null;
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

def cell = props['cell']
def server = props['server']
def commandPath = (props['commandPath']!=null?props['commandPath']:"");
def node = props['node']
def user = props['user']
def password = (props['password'] != null && props['password'] != "")? props['password'] : props['passScript']
def cluster = props['cluster']

def connType = props['connType']
def host = props['host'];
def port = props['port'];
def additionalArgs = props['additionalArgs'];
def appName = props['appName']
def context = props['context']
def location = props['location']
def path = props['path']
def argString = props['argString']

File tempFile = new File("temp.py")
tempFile.deleteOnExit();
BufferedWriter temp = new BufferedWriter(new FileWriter(tempFile))
def cellarg = cell ? " -cell " + cell : ""
def installdir = path ? " -installed.ear.destination " + path : ""
def cellVal;
if (!cell) {
    cellVal = "cell = AdminControl.getCell()"
}
else {
    cellVal = "cell = \"" + cell + "\"";
}

//this only works for server not cluster
def appListCommand
if (cluster) {
    appListCommand = "\nappList = AdminApp.list('WebSphere:cell='+ cell +',cluster=" + cluster + "')";
}
else {
    appListCommand = "\nappList = AdminApp.list('WebSphere:cell='+ cell +',node=" + node + ",server=" + server + "')";
}


def optionsString = " -contents " + location + " -operation update" 
if (context) {
    optionsString = optionsString + " -contextroot " + context;
}
optionsString = optionsString + (argString?(" " +argString):"");

def invokeUpdate = "\n\tAdminApp.update('" + appName + "', 'app', '[" + optionsString + " ]')"

def invokeArgs;
if (cluster) {
    invokeArgs = '[ -cluster ' + cluster + cellarg;
    if (context) {
       invokeArgs = invokeArgs + ' -contextroot ' + context;
    }
    invokeArgs = invokeArgs + ' -appname \"' + appName + '\"' + installdir + ' ' + (argString ? argString :'-usedefaultbindings') + ']';
}
else {
    invokeArgs = '[ -server ' + server + ' -node ' + node + cellarg
    if (context) {
        invokeArgs = invokeArgs + ' -contextroot ' + context; 
    }
    invokeArgs = invokeArgs + ' -appname \"' + appName + '\"' + installdir + ' ' + (argString ? argString :'-usedefaultbindings') + ']'
}
def invokeInstall = "\n\tAdminApp.install('" + location + "', '" + invokeArgs + "')"


// start writing out the file
temp.write(cellVal, 0, cellVal.length());
println cellVal;

temp.write(appListCommand, 0, appListCommand.length());
println appListCommand;

temp.write("\ndoUpdate = 'false'", 0, 19)
println "doUpdate = 'false'"

def nextLine = "\nfor x in appList.splitlines():";
temp.write(nextLine, 0,nextLine.length());
println nextLine;

nextLine = "\n\tif x.rstrip() == '" + appName + "':";
temp.write(nextLine, 0,nextLine.length());
println nextLine;

nextLine = "\n\t\tdoUpdate = 'true'"
temp.write(nextLine, 0,nextLine.length());
println nextLine;

nextLine = "\nif doUpdate == 'true' :";
temp.write(nextLine, 0,nextLine.length());
println nextLine;

//this is where we update not install
temp.write(invokeUpdate, 0, invokeUpdate.length())
System.out.println invokeUpdate

//otherwise
nextLine = "\nelse :";
temp.write(nextLine, 0,nextLine.length());
println nextLine;

//this is where we update
temp.write(invokeInstall, 0, invokeInstall.length())
System.out.println invokeInstall

//time to save the config
temp.write("\nAdminConfig.save()", 0, 19)
System.out.println "AdminConfig.save()"
temp.close()

def commandArgs = [commandPath + wsadmin, "-lang", "jython"];
commandArgs << "-conntype"
commandArgs << connType.trim();

if (host) {
    commandArgs << "-host";
    commandArgs << host;
}

if (port) {
    commandArgs << "-port";
    commandArgs << port;
}

if (user) {
    commandArgs << "-user"
    commandArgs <<  user
    commandArgs << "-password"
    commandArgs << password
}

commandArgs << "-f";
commandArgs << "temp.py";

if (additionalArgs) {
    additionalArgs.split('\n').each { arg ->
        commandArgs << arg;
    }
}

println commandArgs.join(" ");
def procBuilder = new ProcessBuilder(commandArgs);

if (isWindows) {
    def envMap = procBuilder.environment();
    envMap.put("PROFILE_CONFIG_ACTION","true");
}

def statusProc = procBuilder.start();
def outPrint = new PrintStream(out, true);
statusProc.waitForProcessOutput(outPrint, outPrint);
System.exit(statusProc.exitValue());
