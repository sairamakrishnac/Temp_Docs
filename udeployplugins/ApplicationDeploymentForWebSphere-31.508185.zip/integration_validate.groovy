if(cluster && (node || server || cell)) {
  errors.cell = "If cluster is specified than server, node, and cell should not be!"
  errors.node = "If cluster is specified than server, node, and cell should not be!"
  errors.server = "If cluster is specified than server, node, and cell should not be!"
  errors.cluster = "If cluster is specified than server, node, and cell should not be!"
}
if(!cluster) {
    if(!node || !server) {
        errors.node = "A node and Server must be specified if cluster is not specified"
        errors.server = "A node and Server must be specified if cluster is not specified"
    }
}