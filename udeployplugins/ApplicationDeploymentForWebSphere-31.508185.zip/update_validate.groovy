if(contentType.equals("app")) {
    if(!operation.equals("update")) {
        errors.operation = "Operation must be update when Content Type is Application!";
        errors.contentType = "Operation must be update when Content Type is Application!";
    }
    if(contentsuri) {
        errors.contentsuri = "Content URI must be empty when either Application or Partial Application is set for Content Type";
    }
} else if(contentType.equals("file")) {
    if(!contentsuri) {
        errors.contentsuri = "Content URI can not be empty when either File or Module File is set for Content Type";
    }
} else if(contentType.equals("modulefile")) {
    if(!contentsuri) {
        errors.contentsuri = "Content URI can not be empty when either File or Module File is set for Content Type";
    }
} else if(contentType.equals("partialapp")) {
    if(!operation.equals("update")) {
        errors.operation = "Operation must be update when Content Type is Partial Application!";
        errors.contentType = "Operation must be update when Content Type is Partial Application!";
    }
    if(contentsuri) {
        errors.contentsuri = "Content URI must be empty when either Application or Partial Application is set for Content Type";
    }
}
