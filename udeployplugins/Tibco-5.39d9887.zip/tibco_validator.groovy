if(password && passwordscript) {
  errors.password = "Either Password or Password Script must be empty!"
  errors.passwordscript = "Either Password or Password Script must be empty!"
}
