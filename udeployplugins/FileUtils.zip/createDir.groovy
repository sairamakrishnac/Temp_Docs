#!/usr/bin/env groovy

import com.urbancode.commons.fileutils.FileUtils

//------------------------------------------------------------------------------
// Utility methods and classes
//------------------------------------------------------------------------------
final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/)
final def ahptool = isWindows ? 'ahptool.cmd' : 'ahptool'

final def getStepProperties = {
  def props = [:]

  def ahptoolProc = [ahptool, "getStepProperties"].execute()
  ahptoolProc.consumeProcessErrorStream(System.out);
  def propertiesXml = ahptoolProc.text
  ahptoolProc.waitFor()
  if (ahptoolProc.exitValue()) {
      throw new Exception("Failed to get step properties from ahptool: " + propertiesXml)
  }
  new XmlSlurper().parseText(propertiesXml).property.each{ propElem ->
      props[propElem.@name.text()] = propElem.text()
  }

  return props;
}

//------------------------------------------------------------------------------
// Load plugin jars
// Required in case explicit dependencies depend on something here (which they do)
//------------------------------------------------------------------------------

// Load AHP API
final File ahpLibHome = new File(System.getenv()['PLUGIN_HOME'] + "/../../../lib")
ahpLibHome.eachFileMatch(~/.*\.jar/){jar ->
   this.class.classLoader.rootLoader.addURL(jar.toURL())
}


//------------------------------------------------------------------------------
//   Actual Step
//------------------------------------------------------------------------------
final def props = getStepProperties()
final def path = props['Path']
final def useAbsPath = props['absolute']
final def failIfExists = props['failIfExists']


if (!useAbsPath) {
  try {
    FileUtils.assertDirectory("./" + path)
    println("Created ./"+path);
  }
  catch (Exception e) {
    println("Failed to create ./"+path + " . Problem: " + e.getMessage());
  }
}
else {
  try {
    FileUtils.assertDirectory(path)
    println("Created "+path);
  }
  catch (Exception e) {
    println("Failed to create "+path + " . Problem: " + e.getMessage());
  }
}  