#!/usr/bin/env groovy

//------------------------------------------------------------------------------
// Utility methods and classes
//------------------------------------------------------------------------------
final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/)
final def ahptool = isWindows ? 'ahptool.cmd' : 'ahptool'

final def getStepProperties = {
  def props = [:]

  def ahptoolProc = [ahptool, "getStepProperties"].execute()
  ahptoolProc.consumeProcessErrorStream(System.out);
  def propertiesXml = ahptoolProc.text
  ahptoolProc.waitFor()
  if (ahptoolProc.exitValue()) {
      throw new Exception("Failed to get step properties from ahptool: " + propertiesXml)
  }
  new XmlSlurper().parseText(propertiesXml).property.each{ propElem ->
      props[propElem.@name.text()] = propElem.text()
  }

  return props;
}

//------------------------------------------------------------------------------
//   Actual Step
//------------------------------------------------------------------------------
final def props = getStepProperties()
final def text = props['text']
final def useAbsPath = props['absolute']
final def matchLines = props['entryLines']

final def path = props['path']

exitCode = 0
def ant = new AntBuilder()

if (!useAbsPath) {
  path = "./" + path
}

/*
flags = "";
if (ignoreCase) {
	flags="i"
}*/


matchLines.eachLine {line->
	pair = line.split(' -> ')
	if (pair.length != 2) {
		exitCode = 1
		println("This entry does not match required format: " + line)
		System.exit(1)
	}
	else {
		matchPattern = pair[0];
		replacePattern = pair[1];
		println("replacing " + matchPattern + " with " + replacePattern)
		ant.replace(file:path, token:matchPattern, value:replacePattern, summary:"true")
		
		/*
		ant.replaceregexp(flags:flags, file:path) {
			regexp(pattern=matchPattern)
			substitution(expression=replacePattern)

		}*/
	}
}