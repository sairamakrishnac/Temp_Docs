#!/usr/bin/env groovy

import com.urbancode.commons.fileutils.FileUtils
import com.urbancode.commons.fileutils.FileDeletionResults
import com.urbancode.anthill3.AHPTool;

import java.io.File

//------------------------------------------------------------------------------
// Utility methods and classes
//------------------------------------------------------------------------------
final def ahptool = new AHPTool()

//------------------------------------------------------------------------------
//   Actual Step
//------------------------------------------------------------------------------
final def props = ahptool.stepProperties
final def path = props['Path']
final def contentsOnly = Boolean.valueOf(props['contentsOnly']);
final def useAbsPath = props['absolute']
final def failIfMissing = props['failIfMissing']

int exitCode = 0;

if (!useAbsPath) {
    path = "./" + path;
}

File dir = new File(path);
if (failIfMissing && !dir.exists()) {
    println(path + "does not exist.")
    exitCode = 1
}
else {
    try {
        FileDeletionResults results = new FileDeletionResults()
        println("Begining recursive delete")

        if (contentsOnly) {
            dir.eachFile{FileUtils.deleteFileWithResultsSafely(results, it)}
        }
        else {
            FileUtils.deleteFileWithResultsSafely(results, dir)
        }

        if (results.isDeleted()) {
            String msg = "Successfully deleted $path";
            if (contentsOnly) {
                msg += " contents";
            }
            println(msg);
        }
        else {
            println("Failed to remove some directories or files.")
            exitCode = 1;
            def files = results.getFailedDeletionFiles()
            files.each {a->
                println "Could not delete: " + a.toString()
            }
        }

        println("Files Deleted: $results.filesDeleted");
        println("Bytes Deleted: ${FileUtils.getNearestBytes(results.bytesDeleted)}");
    }
    catch (Exception e) {
        println("Failed to remove "+path + " . Problem: " + e.getMessage())
        exitCode = 1;
    }
}

System.exit(exitCode)