package com.urbancode.plugin.cvsexport

public class CVSPassword {

    static final int[] SHIFTS = [
        0,      1,      2,      3,      4,      5,      6,      7,      8,
        9,      10,     11,     12,     13,     14,     15,     16,     17,
        18,     19,     20,     21,     22,     23,     24,     25,     26,
        27,     28,     29,     30,     31,     114,    120,    53,     79,
        96,     109,    72,     108,    70,     64,     76,     67,     116,
        74,     68,     87,     111,    52,     75,     119,    49,     34,
        82,     81,     95,     65,     112,    86,     118,    110,    122,
        105,    41,     57,     83,     43,     46,     102,    40,     89,
        38,     103,    45,     50,     42,     123,    91,     35,     125,
        55,     54,     66,     124,    126,    59,     47,     92,     71,
        115,    78,     88,     107,    106,    56,     36,     121,    117,
        104,    101,    100,    69,     73,     99,     63,     94,     93,
        39,     37,     61,     48,     58,     113,    32,     90,     44,
        98,     60,     51,     33,     97,     62,     77,     84,     80,
        85,     223,    225,    216,    187,    166,    229,    189,    222,
        188,    141,    249,    148,    200,    184,    136,    248,    190,
        199,    170,    181,    204,    138,    232,    218,    183,    255,
        234,    220,    247,    213,    203,    226,    193,    174,    172,
        228,    252,    217,    201,    131,    230,    197,    211,    145,
        238,    161,    179,    160,    212,    207,    221,    254,    173,
        202,    146,    224,    151,    140,    196,    205,    130,    135,
        133,    143,    246,    192,    159,    244,    239,    185,    168,
        215,    144,    139,    165,    180,    157,    147,    186,    214,
        176,    227,    231,    219,    169,    175,    156,    206,    198,
        129,    164,    150,    210,    154,    177,    134,    127,    182,
        128,    158,    208,    162,    132,    167,    209,    149,    241,
        153,    251,    237,    236,    171,    195,    243,    233,    253,
        240,    194,    250,    191,    155,    142,    137,    245,    235,
        163,    242,    178,    152
    ]

    static public void addPassword(File passwordFile, String cvsRoot, String password)
    throws IOException {
        def entryList = new ArrayList()
        def boolean isNew = true

        if (passwordFile.exists()) {
            passwordFile.eachLine { line ->
                // does this entry correspond to our root?
                if (line.length() < cvsRoot.length() || !line.substring(0, cvsRoot.length()).equalsIgnoreCase(cvsRoot) ) {
                    entryList << line
                }
            }
            isNew = false
        }

        entryList << "$cvsRoot  ${getEncodedPassword(password)}"

        try {
            entryList.each {entry ->
                passwordFile << entry + System.getProperty('line.separator')
            }
        }
        catch (FileNotFoundException e) {
            if (passwordFile.exists() && passwordFile.isHidden()) {
                throw new IOException(passwordFile + " is hidden and cannot be accessed; unhide it")
            }
            else {
                throw e
            }
        }

        if (isNew && !(System.getProperty('os.name') =~ /(?i)windows/).find()) {
            // Now, if we are on *nix, then we need to chmod 600 <passwordFile>
            try {
                def builder = new ProcessBuilder("chmod", "600", passwordFile.toString())
                def chmod = builder.start();
                chmod.waitFor();
            }
            catch (Throwable t) {
                println "Could not chmod .cvspass file."
            }
        }
    }

    static public String addPasswordToCvsRoot(String cvsroot, String password) {
        String result = ""

        if (cvsroot != null && password != null) {
            int atIndex = cvsroot.indexOf("@")

            if (atIndex > 0) {
                result += cvsroot.substring(0, atIndex)
                result += ":" + password
                result += cvsroot.substring(atIndex, cvsroot.length())
            }
            else {
                result = cvsroot
            }
        }
        else {
            result = cvsroot
        }

        return result
    }

    static public String getEncodedPassword(String password) {
        if (password == null) {
            return "A"
        }
        else {
            byte[] scrambled = new byte[password.length()]
            for (int i = 0; i < password.length(); i++) {
                char c = password.charAt(i)
                scrambled[i] = (byte)(SHIFTS[((int)c) & 255] & 255)
            }
            return "A" + new String(scrambled)
        }
    }
}
