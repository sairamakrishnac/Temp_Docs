#!/usr/bin/env groovy

//------------------------------------------------------------------------------
// Utility methods and classes
//------------------------------------------------------------------------------
final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/)
final def ahptool = isWindows ? 'ahptool.cmd' : 'ahptool'

final def getStepProperties = {
  def props = [:]

  def ahptoolProc = [ahptool, "getStepProperties"].execute()
  ahptoolProc.consumeProcessErrorStream(System.out);
  def propertiesXml = ahptoolProc.text
  ahptoolProc.waitFor()
  if (ahptoolProc.exitValue()) {
      throw new Exception("Failed to get step properties from ahptool: " + propertiesXml)
  }
  new XmlSlurper().parseText(propertiesXml).property.each{ propElem ->
      props[propElem.@name.text()] = propElem.text()
  }

  return props;
}

//------------------------------------------------------------------------------
//   Actual Step
//------------------------------------------------------------------------------
final def props = getStepProperties()
final def text = props['text']
final def useAbsPath = props['absolute']
final def path = props['path']
exitCode = 0

if (!text) {
	text = ""
}
if (!useAbsPath) {
  path = "./" + path
}

try {
	  file = new File("./" + path)
	  file.createNewFile()
	  file.write(text)
      println("Created "+ file.canonicalPath)
      println("With contents: ")
      println(text)
}
  catch (Exception e) {
    println("Failed to create ./"+path + " . Problem: " + e.getMessage());
    exitCode = 1;
}

System.exit(exitCode);  