import groovy.lang.Closure;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import com.urbancode.anthill3.*



//------------------------------------------------------------------------------
// Utility methods and classes
//------------------------------------------------------------------------------
final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/)
final def ahptool = isWindows ? 'ahptool.cmd' : 'ahptool'

final def getStepProperties = {
  def props = [:]

  def ahptoolProc = [ahptool, "getStepProperties"].execute()
  ahptoolProc.consumeProcessErrorStream(System.out);
  def propertiesXml = ahptoolProc.text
  ahptoolProc.waitFor()
  if (ahptoolProc.exitValue()) {
      throw new Exception("Failed to get step properties from ahptool: " + propertiesXml)
  }
  new XmlSlurper().parseText(propertiesXml).property.each{ propElem ->
      props[propElem.@name.text()] = propElem.text()
  }

  return props;
}



//------------------------------------------------------------------------------
//   Actual Step
//------------------------------------------------------------------------------
final def props = getStepProperties()
final def text = props['text']
// final def useAbsPath = props['absolute']
final def matchLines = props['entryLines']

def fileSet = new FileSet(props.baseDir)
fileSet.include(props.includes)
fileSet.exclude(props.excludes)
def editFiles = fileSet.files()
                                                       
//final def path = props['path']
def ant = new AntBuilder()

editFiles.each { theFile ->
  matchLines.eachLine {line->
	pair = line.split(' -> ')
	if (pair.length != 2) {
		exitCode = 1
		println("This entry does not match required format: " + line)
		System.exit(1)
	}
	else {
		matchPattern = pair[0];
		replacePattern = pair[1];
		println("replacing " + matchPattern + " with " + replacePattern + " in " + theFile.getName())
		ant.replace(file:theFile, token:matchPattern, value:replacePattern, summary:"true")
	}
  }
}