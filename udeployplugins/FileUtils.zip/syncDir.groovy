#!/usr/bin/env groovy

//------------------------------------------------------------------------------
// Utility methods and classes
//------------------------------------------------------------------------------
final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/)
final def ahptool = isWindows ? 'ahptool.cmd' : 'ahptool'

final def getStepProperties = {
  def props = [:]

  def ahptoolProc = [ahptool, "getStepProperties"].execute()
  ahptoolProc.consumeProcessErrorStream(System.out);
  def propertiesXml = ahptoolProc.text
  ahptoolProc.waitFor()
  if (ahptoolProc.exitValue()) {
      throw new Exception("Failed to get step properties from ahptool: " + propertiesXml)
  }
  new XmlSlurper().parseText(propertiesXml).property.each{ propElem ->
      props[propElem.@name.text()] = propElem.text()
  }

  return props;
}


//------------------------------------------------------------------------------
//   Actual Step
//------------------------------------------------------------------------------
def ant = new AntBuilder()

final def props = getStepProperties()
final def fromDir = props['SourceDir']
final def toDir = props['DestinationDir']
                        
if (!fromDir) { fromDir = "." }

ant.echo("Preparing Sync from " + fromDir + " to " + toDir)

ant.sync( verbose:"true", todir:toDir) {
   fileset(dir:fromDir, includes:"**") {
      exclude name: "**/.ahs.dig"
      exclude name: "**/.ahs.manifest"
      exclude name: "*.bom" 
   }
}