#!/usr/bin/env groovy

import java.util.regex.Pattern

//------------------------------------------------------------------------------
// Utility methods and classes
//------------------------------------------------------------------------------
final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
final def ahptool = isWindows ? 'ahptool.cmd' : 'ahptool'

final def getStepProperties = {
  def props = [:]

  def ahptoolProc = [ahptool, "getStepProperties"].execute()
  ahptoolProc.consumeProcessErrorStream(System.out);
  def propertiesXml = ahptoolProc.text
  ahptoolProc.waitFor()
  if (ahptoolProc.exitValue()) {
      throw new Exception("Failed to get step properties from ahptool: " + propertiesXml)
  }
  new XmlSlurper().parseText(propertiesXml).property.each{ propElem ->
      props[propElem.@name.text()] = propElem.text()
  }

  return props;
}

//------------------------------------------------------------------------------
// Load plugin jars
//------------------------------------------------------------------------------

final File resourceHome = new File(System.getenv()['PLUGIN_HOME'])
resourceHome.eachFileMatch(~/.*\.jar/){jar ->
   this.class.classLoader.rootLoader.addURL(jar.toURL())
}

//------------------------------------------------------------------------------
// Make the file existence actual check
//------------------------------------------------------------------------------

final def workDir = new File('.').canonicalFile
final def props = getStepProperties()

final def rawPatternString = props['patterns']
final def splitPattern = Pattern.compile("[,\\s]+");
final def rawPatterns = splitPattern.split(rawPatternString);
final def patterns = new ArrayList<String>();
for (rawPattern in rawPatterns) {
    patterns.add(wildcardsToRegex(rawPattern));
}

println("Root dir: " + workDir)
println("Patterns: ")
for (pattern in patterns) {
    println("    " + pattern)
}

final def calculateRelativePath(File root, File file) {
    def rootPath = root.getCanonicalPath()
    def filePath = file.getCanonicalPath()

    def relPath = filePath.replace(rootPath, "")
    if (relPath.startsWith(File.separator)) {
        relPath = relPath.substring(1)
    }

    relPath = relPath.replace("\\", "/")

    return relPath
}

final def matches(File rootDir, File file, String pattern) {
    def patternFound = false

    def filePath = calculateRelativePath(rootDir, file)
    if (filePath.matches(pattern)) {
        println("Found file: " + filePath)
        patternFound = true
    }

    if (!patternFound && file.isDirectory()) {
        def files = file.listFiles()
        for (childFile in files) {
            patternFound = matches(rootDir, childFile, pattern)
            if (patternFound) {
                break
            }
        }
    }

    return patternFound
}

final def wildcardsToRegex(String wildcardPattern) {
    def regex = wildcardPattern
    regex = regex.replace("\\", "/")

    if (regex.endsWith(File.separator)) {
        regex = regex + "**"
    }

    regex = regex.replaceAll("(\\*){2}/", "_______________")
    regex = regex.replaceAll("\\.", "\\\\.")
    regex = regex.replaceAll("\\?", ".")
    regex = regex.replaceAll("\\*", ".*")
    regex = regex.replaceAll("_______________", "(.*/)*")

    return regex
}

for (pattern in patterns) {
    def patternFound = matches(workDir, workDir, pattern)
    if (!patternFound) {
        throw new Exception("Files matching all pattern " + pattern + " not found")
    }
}

println("Files matching all patterns found")
